add firebug .xpi here for the plugin tests to work

https://getfirebug.com/downloads/