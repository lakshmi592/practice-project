package com.sayem.screenshot;

public class ScreenShot {
}
