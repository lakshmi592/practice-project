package com.sayem.doubleclick;

public class DoubleClick {
}
