package com.sayem.firefoxbrowser;

public class CustomProfile {
}
