package com.sayem.pagefactory;

public class PageFactory {
}
