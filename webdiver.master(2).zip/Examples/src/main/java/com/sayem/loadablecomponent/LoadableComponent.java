package com.sayem.loadablecomponent;

public class LoadableComponent {
}
