package com.sayem.explicitwait;

public class ExplicitWait {
}
