package com.sayem.ajax;

public class Ajax {
}
