package com.sayem.browser.mouse;

public class ActionClass {
}
