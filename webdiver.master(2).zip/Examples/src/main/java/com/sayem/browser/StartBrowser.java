package com.sayem.browser;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class StartBrowser {

	public static void main(String[] args) {
		WebDriver dr = new FirefoxDriver();
	}

}
