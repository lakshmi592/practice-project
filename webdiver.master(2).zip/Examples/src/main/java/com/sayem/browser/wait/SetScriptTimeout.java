package com.sayem.browser.wait;

public class SetScriptTimeout {
}
