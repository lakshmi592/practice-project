package com.sayem.logger;

public class Logging {
}
