package com.sayem.alert;

public class Alert {
}
