package com.sayem.implicitwait;

public class ImplicitWait {
}
