package com.sayem.safaribrowser;

public class Safari {
}
