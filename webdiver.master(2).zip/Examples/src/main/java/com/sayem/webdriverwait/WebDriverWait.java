package com.sayem.webdriverwait;

public class WebDriverWait {
}
